// Das *unvermeidliche* Hello World! Beispiel

public class Hello {

       public static void main(String[ ] args) {
               System.out.println("Hallo Mannheim");
       }

}
