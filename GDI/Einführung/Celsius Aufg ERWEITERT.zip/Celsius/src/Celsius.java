// Demo Programm f�r die erste �bung

import java.util.*;


// Programm zur Berechnung der Fahrenheit Temperatur 
// bei bekannter Celsius Temperatur

// Author m.jando
// Programm erweritert. Buchstaben und Sonderzeichen werden abgefangen
public class Celsius {

	public static void main(String[] args) {
		
		// Ben�tigte Variablen deklarieren
		double epsilon = 0.005;
		double c = 0.0, f;
		String pru;
		Boolean match=false;
		// Fuer die Eingabe von der Tastatur
		Scanner in = new Scanner(System.in);
		
		// Berechnungsschleife
		do {
			// Anleitung
			System.out.println("Programm endet durch Eingabe von 0");
			System.out.println("Eingabe der Celsius-Temperatur: ");
			// Eingabe, Double-Wert einlesen
	
				pru = in.next();
				// Try, Catch, Finally kann an dieser Stelle nicht verwendet werden, 
				// da Scanner den Status von try catch (die Exception) nicht zur�cksetzt. --> Endlos-Schleife
				// Deswegen Regular-Expression(Regex) nehmen.
				
				
				//Pr�fung ob eingegebener Wert eine Zahl ist. Hierbei werden folgende Formate unters�tzt: 
				//X.X Stellen vor und hinter dem Komma k�nnen eine beliebige Anzahl haben
				// Was nicht funktioniert ist: 60.1G --> 60.1 funktioniert
				if(pru.matches("([\\+\\-])?(\\d+(\\.\\d+)?)(?![\\d.x])")){
				// Umrechnen in Fahrenheit
				c = Double.parseDouble(pru);
				f = c * (9.0/5.0) + 32.0;
				// Ausgabe des Ergebnis
				System.out.println("... in Fahrenheit: " + f + " Grad \n");
				System.out.println("");
				}
				else{
					System.out.println("Das ist leider keine g�ltige Zahl!");
					System.out.println("Bitte geben Sie eine g�ltige Zahl ein!");
					System.out.println("");
				}
		// Schleife durch Eingabe von 0 verlassen?
		} while (Math.abs(c) > epsilon);
		
		System.out.println("... und tsch�ss");
		in.close();
	}
}
